const { app, BrowserWindow, dialog, utilityProcess, Menu, session, shell } = require('electron');
const path = require('node:path');
const fs = require('node:fs');
const net = require('node:net');
const PORT = 47831; // Fixed origin preserves IndexedDB/OPFS across launches.
const ORIGIN = `http://127.0.0.1:${PORT}`;
const dataDir = process.env.OPENCUT_TEST_DATA || path.join(process.env.PORTABLE_EXECUTABLE_DIR || path.dirname(app.getPath('exe')), 'OpenCut-data');
try { fs.mkdirSync(dataDir, { recursive: true }); fs.accessSync(dataDir, fs.constants.W_OK); app.setPath('userData', dataDir); }
catch { dialog.showErrorBox('OpenCut', 'Coloque o executável em uma pasta onde você possa gravar arquivos.'); app.exit(1); }
let server, window, quitting = false;
if (!app.requestSingleInstanceLock()) app.quit();
else {
  app.on('second-instance', () => { if (window) { if (window.isMinimized()) window.restore(); window.focus(); } });
  app.whenReady().then(start).catch(error => { dialog.showErrorBox('OpenCut não iniciou', error.message); app.quit(); });
}
async function start() {
  await new Promise((resolve, reject) => {
    const probe = net.createServer();
    probe.once('error', () => reject(new Error(`A porta local ${PORT} está ocupada. Feche a outra instância e tente novamente.`)));
    probe.listen(PORT, '127.0.0.1', () => probe.close(resolve));
  });
  const base = app.isPackaged ? path.join(process.resourcesPath, 'web') : path.join(__dirname, 'web-runtime');
  const cwd = path.join(base, 'apps/portable-web');
  const log = fs.createWriteStream(path.join(dataDir, 'desktop.log'), { flags: 'a' });
  server = utilityProcess.fork(path.join(cwd, 'server.js'), [], { cwd, stdio: 'pipe', env: { ...process.env, NODE_ENV: 'production', HOSTNAME: '127.0.0.1', PORT: String(PORT), NEXT_TELEMETRY_DISABLED: '1' } });
  server.stdout.on('data', chunk => log.write(chunk));
  server.stderr.on('data', chunk => log.write(chunk));
  let exited = false;
  server.on('exit', code => { exited = true; if (!quitting) { dialog.showErrorBox('OpenCut', `Servidor local encerrou (${code}). Consulte OpenCut-data/desktop.log.`); app.quit(); } });
  let ready = false;
  for (let i = 0; i < 120 && !exited; i++) {
    try { const response = await fetch(`${ORIGIN}/projects`); if (response.ok) { ready = true; break; } } catch {}
    await new Promise(resolve => setTimeout(resolve, 500));
  }
  if (!ready) throw new Error('O editor local não respondeu em 60 segundos. Consulte OpenCut-data/desktop.log.');
  session.defaultSession.setPermissionRequestHandler((_contents, permission, callback) => callback(permission === 'clipboard-sanitized-write'));
  session.defaultSession.setPermissionCheckHandler((_contents, permission) => permission === 'clipboard-sanitized-write');
  window = new BrowserWindow({ width: 1440, height: 960, minWidth: 1024, minHeight: 700, backgroundColor: '#141414', webPreferences: { nodeIntegration: false, contextIsolation: true, sandbox: true } });
  const external = url => { if (/^https:\/\//.test(url)) shell.openExternal(url); };
  window.webContents.setWindowOpenHandler(({ url }) => { external(url); return { action: 'deny' }; });
  window.webContents.on('will-navigate', (event, url) => { if (new URL(url).origin !== ORIGIN) { event.preventDefault(); external(url); } });
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    { label: 'Arquivo', submenu: [{ label: 'Projetos', click: () => window.loadURL(`${ORIGIN}/projects`) }, { label: 'Abrir pasta de dados', click: () => shell.openPath(dataDir) }, { type: 'separator' }, { role: 'quit', label: 'Sair' }] },
    { label: 'Editar', submenu: [{ role: 'undo' }, { role: 'redo' }, { type: 'separator' }, { role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { role: 'selectAll' }] },
    { label: 'Exibir', submenu: [{ role: 'togglefullscreen' }, { role: 'toggleDevTools' }] }
  ]));
  await window.loadURL(`${ORIGIN}/projects`);
}
app.on('window-all-closed', () => app.quit());
// A renderer may cancel closing while a save is pending. Keep the server alive
// until Electron has actually accepted closing all windows.
app.on('will-quit', () => { quitting = true; server?.kill(); });
