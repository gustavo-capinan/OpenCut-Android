$ErrorActionPreference = 'Stop'
$base = Split-Path -Parent $PSScriptRoot
$source = Join-Path $base 'source'
if (Test-Path -LiteralPath $source) { throw 'A pasta source já existe; use uma pasta nova para esta compilação.' }
git clone https://github.com/OpenCut-app/opencut-classic.git $source
if ($LASTEXITCODE -ne 0) { throw 'Falha ao obter o código original.' }
git -C $source checkout cf5e79e919144200294fb9fed22a222592a0aeea
if ($LASTEXITCODE -ne 0) { throw 'Falha ao selecionar a versão fixa.' }
Copy-Item -LiteralPath $PSScriptRoot -Destination (Join-Path $source 'desktop') -Recurse
Push-Location $source
try {
  npx --yes bun@1.2.18 install --frozen-lockfile
  if ($LASTEXITCODE -ne 0) { throw 'Falha nas dependências upstream.' }
  npm ci --prefix desktop --workspaces=false
  if ($LASTEXITCODE -ne 0) { throw 'Falha nas dependências desktop.' }
  node desktop/node_modules/electron/install.js
  if ($LASTEXITCODE -ne 0) { throw 'Falha ao obter Electron.' }
  node desktop/build-web.cjs
  if ($LASTEXITCODE -ne 0) { throw 'Falha na compilação web.' }
  npm --prefix desktop run dist
  if ($LASTEXITCODE -ne 0) { throw 'Falha no empacotamento.' }
  node desktop/smoke.cjs
  if ($LASTEXITCODE -ne 0) { throw 'Falha no teste do aplicativo.' }
  node desktop/test-portable.cjs
  if ($LASTEXITCODE -ne 0) { throw 'Falha no teste do executável portátil.' }
} finally { Pop-Location }
