const { chromium } = require('playwright');
const { spawn } = require('node:child_process');
const path = require('node:path');
const fs = require('node:fs');
const assert = require('node:assert/strict');
const root = path.join(__dirname, 'test-results', `portable launch ${Date.now()}`);
fs.mkdirSync(root, { recursive: true });
const executable = path.join(root, 'OpenCut Portable.exe');
fs.copyFileSync(path.join(__dirname, 'release/OpenCut-Classic-Portable-0.1.0-win-x64.exe'), executable);
async function boot() {
  const processHandle = spawn(executable, ['--remote-debugging-port=49381'], { cwd: root, windowsHide: true, stdio: 'ignore' });
  let browser;
  for (let i = 0; i < 120; i++) {
    try { browser = await chromium.connectOverCDP('http://127.0.0.1:49381'); break; } catch {}
    await new Promise(resolve => setTimeout(resolve, 500));
  }
  assert.ok(browser, 'Portable launcher must start Electron');
  const context = browser.contexts()[0];
  await context.route('**/*', route => new URL(route.request().url()).hostname === '127.0.0.1' ? route.continue() : route.abort());
  let page;
  for (let i = 0; i < 120; i++) {
    page = context.pages().find(p => p.url().includes('/projects'));
    if (page) break;
    await new Promise(resolve => setTimeout(resolve, 500));
  }
  assert.ok(page);
  page.setDefaultTimeout(30000);
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.getByRole('button', { name: 'New project', exact: true }).waitFor();
  return { browser, page, processHandle };
}
async function close(instance) {
  if (instance.browser.isConnected()) {
    const cdp = await instance.browser.newBrowserCDPSession();
    await cdp.send('Browser.close').catch(error => { if (!/closed/i.test(error.message)) throw error; });
    await instance.browser.close();
  }
  for (let i = 0; i < 60 && instance.processHandle.exitCode === null; i++) await new Promise(resolve => setTimeout(resolve, 500));
}
(async () => {
  let instance = await boot();
  try {
    await instance.page.getByRole('button', { name: 'Create your first project', exact: true }).click();
    await instance.page.waitForURL('**/editor/**');
    const closeButton = instance.page.getByRole('button', { name: 'Close', exact: true });
    const importer = instance.page.getByRole('button', { name: 'Import', exact: true });
    await closeButton.or(importer).first().waitFor();
    if (await closeButton.isVisible()) await closeButton.click();
    await instance.page.getByRole('button', { name: 'Import', exact: true }).waitFor();
    await instance.page.waitForTimeout(1500);
    await instance.page.screenshot({ path: path.join(__dirname, 'test-results/portable-launch.png') });
    await close(instance); instance = null;
    assert.ok(fs.existsSync(path.join(root, 'OpenCut-data', 'IndexedDB')));
    instance = await boot();
    await instance.page.locator('a[href^="/editor/"]').first().waitFor();
    fs.writeFileSync(path.join(__dirname, 'test-results/portable-launch.json'), JSON.stringify({ passed: true, actualPortableExe: true, pathWithSpaces: true, defaultAdjacentDataFolder: true, persistedAfterRestart: true }, null, 2));
    console.log('Actual portable executable launch and persistence passed.');
  } finally { if (instance) await close(instance); }
})().catch(error => { console.error(error); process.exit(1); });


