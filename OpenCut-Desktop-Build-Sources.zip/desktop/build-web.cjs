const { spawnSync } = require('node:child_process');
const path = require('node:path');
require('./prepare-web.cjs');
const cwd = path.resolve(__dirname, '../apps/portable-web');
const next = require.resolve('next/dist/bin/next', { paths: [cwd] });
const result = spawnSync(process.execPath, [next, 'build', '--webpack'], { cwd, stdio: 'inherit', env: { ...process.env, NEXT_TELEMETRY_DISABLED: '1' } });
process.exit(result.status ?? 1);
