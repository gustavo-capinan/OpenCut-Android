const fs = require('node:fs');
const path = require('node:path');
const seen = new Set();
const notices = ['# Third-party dependency notices\n\nIncludes build-time dependencies for completeness. Electron/Chromium notices also ship in the application runtime.'];
function scan(modules) {
  if (!fs.existsSync(modules)) return;
  for (const name of fs.readdirSync(modules)) {
    if (name.startsWith('.')) continue;
    const dir = path.join(modules, name);
    if (name.startsWith('@')) { scan(dir); continue; }
    const file = path.join(dir, 'package.json');
    if (!fs.existsSync(file)) continue;
    const pkg = JSON.parse(fs.readFileSync(file, 'utf8'));
    const key = `${pkg.name}@${pkg.version}`;
    if (seen.has(key)) continue;
    seen.add(key);
    notices.push(`\n## ${key}\nLicense metadata: ${JSON.stringify(pkg.license ?? 'not specified')}\n`);
    for (const entry of fs.readdirSync(dir)) {
      if (/^(licen[sc]e|copying|notice)([.\-_]|$)/i.test(entry) && fs.statSync(path.join(dir, entry)).isFile()) notices.push(fs.readFileSync(path.join(dir, entry), 'utf8'));
    }
    scan(path.join(dir, 'node_modules'));
  }
}
scan(path.resolve(__dirname, '../node_modules'));
scan(path.resolve(__dirname, '../apps/web/node_modules'));
scan(path.join(__dirname, 'node_modules'));
fs.writeFileSync(path.join(__dirname, 'THIRD-PARTY-NOTICES.txt'), notices.join('\n'));
console.log(`Collected notices for ${seen.size} dependencies.`);
