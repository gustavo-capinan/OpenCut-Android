const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const source = path.join(root, 'apps/web');
const target = path.join(root, 'apps/portable-web');
// Only this generated directory is removed. Never modify upstream source files.
fs.rmSync(target, { recursive: true, force: true });
fs.mkdirSync(target, { recursive: true });
for (const name of ['src', 'public', 'postcss.config.mjs', 'tsconfig.json']) {
  fs.cpSync(path.join(source, name), path.join(target, name), { recursive: true });
}
const app = path.join(target, 'src/app');
for (const entry of fs.readdirSync(app)) {
  if (!['projects', 'editor', 'globals.css'].includes(entry)) fs.rmSync(path.join(app, entry), { recursive: true, force: true });
}
const write = (name, text) => fs.writeFileSync(path.join(target, name), text);
for (const route of ['projects', 'editor/[project_id]']) {
  fs.renameSync(path.join(app, route, 'page.tsx'), path.join(app, route, 'client.tsx'));
  write(`src/app/${route}/page.tsx`, `"use client"; import dynamic from 'next/dynamic'; const Editor = dynamic(() => import('./client'), { ssr: false }); export default Editor;`);
}
// Upstream refactoring left positional calls to APIs that now take named objects.
// Preserve migration behavior and persisted records; change only call signatures.
for (const name of ['runner.ts', 'v1-to-v2.ts']) {
  const file = `src/services/storage/migrations/${name}`;
  let text = fs.readFileSync(path.join(target, file), 'utf8');
  text = text.replace(/new IndexedDBAdapter<([^>]+)>\(\s*([^,]+),\s*([^,]+),\s*1,\s*\)/g,
    'new IndexedDBAdapter<$1>({ dbName: $2, storeName: $3, version: 1 })');
  text = text.replace('projectsAdapter.set(projectId, result.project)', 'projectsAdapter.set({ key: projectId, value: result.project })');
  write(file, text);
}
const providers = 'src/stickers/providers/index.ts';
write(providers, fs.readFileSync(path.join(target, providers), 'utf8').replace('stickersRegistry.register(provider.id, provider)', 'stickersRegistry.register({ key: provider.id, definition: provider })'));
write('package.json', JSON.stringify({ name: '@opencut/portable-web', private: true, version: '0.1.0' }));
write('next.config.ts', `import type { NextConfig } from 'next';
const config: NextConfig = { output: 'standalone', images: { unoptimized: true }, experimental: { cpus: 2 }, outputFileTracingRoot: ${JSON.stringify(root)}, webpack(config) { config.experiments = { ...config.experiments, asyncWebAssembly: true }; return config; } };
export default config;`);
write('src/app/layout.tsx', `import { ThemeProvider } from 'next-themes';
import { Toaster } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import './globals.css';
export const metadata = { title: 'OpenCut Classic Portable' };
export default function Layout({ children }: { children: React.ReactNode }) {
return <html lang="en" suppressHydrationWarning><body className="font-sans antialiased"><ThemeProvider attribute="class" defaultTheme="dark"><TooltipProvider><Toaster />{children}</TooltipProvider></ThemeProvider></body></html>;
}`);
write('src/app/page.tsx', `import { redirect } from 'next/navigation'; export default function Home() { redirect('/projects'); }`);
write('src/changelog/components/changelog-notification.tsx', 'export function ChangelogNotification() { return null; }');
write('src/feedback/components/feedback-popover.tsx', 'export function FeedbackPopover() { return null; }');
write('src/sounds/components/assets-view.tsx', `export function SoundsView() { return <p className="p-4 text-sm">A biblioteca online de sons não está disponível nesta edição. Importe arquivos de áudio na aba Media.</p>; }`);
// Limit typechecking to the desktop entry graph; unrelated website/server routes are not shipped.
const ts = JSON.parse(fs.readFileSync(path.join(target, 'tsconfig.json'), 'utf8'));
ts.include = ['next-env.d.ts', 'src/app/**/*.tsx', 'src/types/**/*.d.ts', '.next/types/**/*.ts'];
write('tsconfig.json', JSON.stringify(ts, null, 2));
console.log('Desktop web source prepared:', target);
