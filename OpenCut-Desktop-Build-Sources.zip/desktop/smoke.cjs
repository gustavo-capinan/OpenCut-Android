const { _electron: electron } = require('playwright');
const path = require('node:path');
const fs = require('node:fs');
const assert = require('node:assert/strict');
const results = path.join(__dirname, 'test-results');
const profile = path.join(results, `smoke-${Date.now()}`);
const executablePath = path.join(__dirname, 'release/win-unpacked/OpenCut Classic Portable.exe');
const report = { time: new Date().toISOString(), executablePath, offline: true, exports: {}, pageErrors: [] };
const launch = () => electron.launch({ executablePath, env: { ...process.env, OPENCUT_TEST_DATA: profile }, timeout: 90000 });
async function ready(app) {
  const page = await app.firstWindow();
  page.setDefaultTimeout(30000);
  // Block external network while retaining the local bundled server.
  await page.context().route('**/*', route => {
    const u = new URL(route.request().url());
    return ['127.0.0.1', 'localhost'].includes(u.hostname) || ['blob:', 'data:'].includes(u.protocol) ? route.continue() : route.abort();
  });
  page.on('pageerror', error => report.pageErrors.push(error.message));
  page.on('dialog', dialog => dialog.accept().catch(() => {}));
  await page.getByRole('button', { name: 'New project', exact: true }).waitFor();
  return page;
}
function wav() {
  const rate = 48000, count = rate * 2, b = Buffer.alloc(44 + count * 2);
  b.write('RIFF'); b.writeUInt32LE(b.length - 8, 4); b.write('WAVEfmt ', 8); b.writeUInt32LE(16, 16); b.writeUInt16LE(1, 20); b.writeUInt16LE(1, 22); b.writeUInt32LE(rate, 24); b.writeUInt32LE(rate * 2, 28); b.writeUInt16LE(2, 32); b.writeUInt16LE(16, 34); b.write('data', 36); b.writeUInt32LE(count * 2, 40);
  for (let i = 0; i < count; i++) b.writeInt16LE(Math.round(Math.sin(i * 2 * Math.PI * 440 / rate) * 5000), 44 + i * 2);
  return b;
}
(async () => {
  fs.mkdirSync(results, { recursive: true });
  let app = await launch();
  try {
    let page = await ready(app);
    await page.getByRole('button', { name: 'Create your first project', exact: true }).click();
    await page.waitForURL('**/editor/**');
    const close = page.getByRole('button', { name: 'Close', exact: true });
    const importer = page.getByRole('button', { name: 'Import', exact: true });
    await close.or(importer).first().waitFor();
    if (await close.isVisible()) await close.click();
    await page.getByRole('button', { name: 'Import', exact: true }).waitFor();
    report.codecs = await page.evaluate(async () => ({
      vp9: (await VideoEncoder.isConfigSupported({ codec: 'vp09.00.10.08', width: 640, height: 360 })).supported,
      h264: (await VideoEncoder.isConfigSupported({ codec: 'avc1.42001f', width: 640, height: 360 })).supported,
      aac: (await AudioEncoder.isConfigSupported({ codec: 'mp4a.40.2', sampleRate: 48000, numberOfChannels: 1, bitrate: 128000 })).supported,
      webgpu: !!(await navigator.gpu?.requestAdapter())
    }));
    const png = await page.evaluate(() => { const c = document.createElement('canvas'); c.width = 640; c.height = 360; const x = c.getContext('2d'); x.fillStyle = '#00aabb'; x.fillRect(0, 0, 640, 360); x.fillStyle = '#fff'; x.font = '40px Arial'; x.fillText('OpenCut portable test', 40, 160); return c.toDataURL().split(',')[1]; });
    for (const file of [{ name: 'portable-test.png', mimeType: 'image/png', buffer: Buffer.from(png, 'base64') }, { name: 'tone.wav', mimeType: 'audio/wav', buffer: wav() }]) {
      await page.locator('input[type=file]').first().setInputFiles(file);
      const asset = page.getByTitle(file.name, { exact: true }).first();
      await asset.waitFor();
      await asset.hover();
      await asset.locator('..').getByRole('button').click({ force: true });
    }
    await page.screenshot({ path: path.join(results, 'packaged-editor.png') });
    for (const format of ['webm', 'mp4']) {
      const destination = path.join(results, `smoke-export.${format}`);
      await app.evaluate(({ session }, dest) => {
        globalThis.downloadState = 'waiting';
        session.defaultSession.removeAllListeners('will-download');
        session.defaultSession.on('will-download', (_event, item) => { item.setSavePath(dest); item.once('done', (_event, state) => { globalThis.downloadState = state; }); });
      }, destination);
      await page.getByRole('button', { name: 'Export', exact: true }).click();
      await page.getByRole('button', { name: 'Format', exact: true }).click();
      await page.getByRole('radio', { name: format === 'webm' ? /WebM/ : /MP4/ }).click();
      await page.getByRole('button', { name: 'Export', exact: true }).last().click();
      let state;
      for (let i = 0; i < 180; i++) {
        state = await app.evaluate(() => globalThis.downloadState);
        if (state !== 'waiting') break;
        if (await page.getByText('Export failed', { exact: true }).count()) throw new Error(await page.locator('body').innerText());
        await page.waitForTimeout(1000);
      }
      assert.equal(state, 'completed', `${format} export must complete`);
      const buffer = fs.readFileSync(destination);
      assert.ok(buffer.length > 1000);
      const media = await page.evaluate(async ({ base64, format }) => {
        const bytes = Uint8Array.from(atob(base64), c => c.charCodeAt(0));
        const url = URL.createObjectURL(new Blob([bytes], { type: `video/${format}` }));
        const v = document.createElement('video'); v.muted = true; v.src = url;
        await new Promise((resolve, reject) => { v.onloadeddata = resolve; v.onerror = () => reject(new Error('Export cannot decode')); });
        await new Promise((resolve, reject) => {
          const timer = setTimeout(() => reject(new Error('Decoded video frame timed out')), 15000);
          v.requestVideoFrameCallback(() => { clearTimeout(timer); resolve(); });
          v.currentTime = 1;
        });
        const c = document.createElement('canvas'); c.width = v.videoWidth; c.height = v.videoHeight;
        const x = c.getContext('2d'); x.drawImage(v, 0, 0); const pixel = [...x.getImageData(20, 20, 1, 1).data];
        const a = new AudioContext(); const audio = await a.decodeAudioData(bytes.buffer.slice(0));
        const samples = audio.getChannelData(0); let energy = 0; for (const s of samples) energy += s * s;
        const result = { width: v.videoWidth, height: v.videoHeight, duration: v.duration, pixel, audioChannels: audio.numberOfChannels, audioRms: Math.sqrt(energy / samples.length) };
        await a.close(); URL.revokeObjectURL(url); return result;
      }, { base64: buffer.toString('base64'), format });
      report.exports[format] = { bytes: buffer.length, ...media };
      console.log(format, report.exports[format]);
      assert.ok(media.duration >= 4.9 && media.duration <= 5.1);
      assert.ok(media.pixel[1] > 100 && media.pixel[2] > 100, 'Export must contain the imported image');
      assert.ok(media.audioRms > 0.01, 'Export must contain non-silent audio');
    }
    const projectUrl = page.url();
    await app.close(); app = await launch(); page = await ready(app);
    await page.locator('a[href^="/editor/"]').first().click();
    await page.getByRole('button', { name: 'Import', exact: true }).waitFor();
    assert.equal(page.url(), projectUrl);
    await page.getByTitle('portable-test.png', { exact: true }).waitFor();
    await page.getByTitle('tone.wav', { exact: true }).waitFor();
    assert.ok((await page.locator('body').innerText()).includes('00:00:05:00'));
    report.persistence = true;
    // Reimport the exported movie, then exercise a real timeline split.
    await page.locator('input[type=file]').first().setInputFiles(path.join(results, 'smoke-export.mp4'));
    const movie = page.getByTitle('smoke-export.mp4', { exact: true });
    await movie.waitFor(); await movie.hover();
    await movie.locator('..').getByRole('button').click({ force: true });
    await page.getByTitle('Click to edit time').click();
    const timeInput = page.getByPlaceholder('00:00:00:00');
    await timeInput.fill('00:00:01:00'); await timeInput.press('Enter');
    await page.getByRole('button', { name: 'smoke-export.mp4', exact: true }).click();
    await page.keyboard.press('s');
    await page.waitForTimeout(2000);
    assert.equal(await page.getByRole('button', { name: 'smoke-export.mp4', exact: true }).count(), 2);
    report.videoSplit = true;
    report.videoImported = true;
    assert.deepEqual(report.pageErrors, []);
    report.passed = true;
  } catch (error) {
    report.failure = String(error);
    const failedPage = app.windows()[0];
    if (failedPage) {
      await failedPage.screenshot({ path: path.join(results, 'failure.png') }).catch(() => {});
      report.visiblePage = await failedPage.locator('body').innerText().catch(() => 'unavailable');
      report.url = failedPage.url();
    }
    throw error;
  } finally {
    await app.close();
    fs.writeFileSync(path.join(results, 'smoke.json'), JSON.stringify(report, null, 2));
  }
})().catch(error => { console.error(error); process.exit(1); });


