# OpenCut Classic Portable — Windows x64

Empacotamento desktop comunitário, não oficial, sob licença MIT.

## Compilar localmente

Instale Git e Node.js 24.22.0. Extraia este ZIP numa pasta nova e execute:

```powershell
powershell -ExecutionPolicy Bypass -File .\desktop\bootstrap.ps1
```

O script baixa o repositório oficial `OpenCut-app/opencut-classic`, seleciona
o commit `cf5e79e919144200294fb9fed22a222592a0aeea`, instala dependências,
compila, empacota e testa. A saída fica em `source/desktop/release/`.
É necessária internet para compilar; não para a edição básica depois de compilado.

## GitHub Actions

Este ZIP contém os arquivos de um repositório de empacotamento independente.
Sugestão de nome: `OpenCut-Desktop`. Também pode ser usado no repositório vazio
`gustavo-capinan/OpenCut-Android`, apesar do nome histórico.

Envie os arquivos desta pasta para o repositório, preservando `.github/workflows`.
Em Actions, selecione **OpenCut Classic Portable Windows x64 → Run workflow**.
Após uma execução bem-sucedida, baixe o artefato **OpenCut-Classic-Portable-win-x64**.
Contém o executável, checksum e evidências dos testes. Retenção: 30 dias.
O workflow não cria uma Release automaticamente.

**Estado desta entrega:** compilação e testes realizados localmente. A integração
GitHub recusou a escrita com HTTP 403; não houve publicação ou execução remota.

Leia `desktop/README.pt-BR.md` para uso, armazenamento e limites de offline;
`desktop/VALIDATION.md` descreve o que foi testado. O executável não é assinado.
Para mover seus projetos, copie também a pasta `OpenCut-data` com o app fechado.
